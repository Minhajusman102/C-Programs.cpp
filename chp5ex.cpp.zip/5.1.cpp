#include<iostream>
using namespace std;
int main()
{
	int day,cd,cw;
	day=1;
	cw=0;
	while (day<=7)
	{
		cout<<"Enter calories burned in a day: ";
		cin>>cd;
		cout<<endl;
		cw=cw+cd;
		day=day+1;
		
	}
	cout<<"Average number of calories burned per day: "<<cw/7;
	return 0;
	
}
