#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
string name;
int volun,boxes,tot,counter;
float cost;
cout<<fixed<<showpoint<<setprecision(2);
cout<<"Enter the no of volunteers: ";
cin>>volun;
cout<<endl;
tot=0;
	counter=0;
	while(counter<volun)
	{
		cout<<"Enter the name and no of boxes:";
		cin>>name>>boxes;
		cout<<endl;
		tot=tot+boxes;
		counter ++;
		
	}
	cout<<"Total no of boxes sold: "<<tot<<endl;
	cout<<"Enter the cost of one box: ";
	cin>>cost;
	cout<<"Total money made by selling cookies: "<<tot*cost<<endl;
	if(counter!=0)
	{
		cout<<"Average no on boxes sold by each volunteer: "<<tot/counter<<endl;
		
	}
	else 
	cout<<"No input.. ";
	return 0;
}
