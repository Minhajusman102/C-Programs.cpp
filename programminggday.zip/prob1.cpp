#include<iostream>
using namespace std;
int main()
{
    string temp,humi;
    cout<<"Enter the temp(warm or cold): ";
    cin>>temp;
    cout<<"Enter the humidity(dry or humid): ";
    cin>>humi;
    if(temp=="warm")
    {
        if(humi=="dry")
        cout<<"\n Play tennis .. ";
        if(humi=="humid")
        cout<<"\n swim .. ";
    }
    if (temp=="cold")
    {
        if(humi=="dry")
        cout<<"\n Play basketball .. ";
        if(humi=="humid")
        cout<<"\n watch tv .. ";
    }
    return 0;
}