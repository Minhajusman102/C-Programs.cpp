#include <iostream>
using namespace std;

int main() {
    char serviceCode, timeCode;
    double minutes, minutesDay, minutesNight, billAmount = 0;

    cout << "Enter type of customer (Regular or Premium) (r/p): ";
    cin >> serviceCode;

    if (serviceCode == 'r' || serviceCode == 'R') {
        // Regular service
        cout << "Enter total minutes used: ";
        cin >> minutes;

        billAmount = 10.00; // base charge
        if (minutes > 50)
            billAmount += (minutes - 50) * 0.20;

        cout << "Service Type: Regular" << endl;
        cout << "Total Charges: $" << billAmount << endl;
    }

    else if (serviceCode == 'p' || serviceCode == 'P') {
        // Premium service
        cout << "Enter time of use (D for day / N for night): ";
        cin >> timeCode;

        billAmount = 25.00; // base charge

        if (timeCode == 'D' || timeCode == 'd') {
            cout << "Enter minutes used during the day: ";
            cin >> minutesDay;

            if (minutesDay > 75)
                billAmount += (minutesDay - 75) * 0.10;
        }
        else if (timeCode == 'N' || timeCode == 'n') {
            cout << "Enter minutes used during the night: ";
            cin >> minutesNight;

            if (minutesNight > 100)
                billAmount += (minutesNight - 100) * 0.05;
        }
        else {
            cout << "Invalid time code!" << endl;
        }

        cout << "Service Type: Premium" << endl;
        cout << "Total Charges: $" << billAmount << endl;
    }

    else {
        cout << "Invalid service type!" << endl;
    }

    return 0;
}