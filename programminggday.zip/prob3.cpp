#include<iostream>
using namespace std;
int main()
{
    int m1,m2,m3,m4,m5,total;
    string name;
    float per;
    cout<<"Enter your name: ";
    cin>>name;
    cout<<"Enter the english marks: ";
    cin>>m1;
    cout<<"Enter the Math marks: ";
    cin>>m2;
    cout<<"Enter the Chemistry marks: ";
    cin>>m3;
    cout<<"Enter the Social sciences marks: ";
    cin>>m4;
    cout<<"Enter the biology marks: ";
    cin>>m5;
    total=m1+m2+m3+m4+m5;
    per=(total/500.0)*100;
    cout<<"Your name is : "<<name;
    cout<<"\n Total marks: "<<total;
    cout<<"\n percentage: "<<per;
    if(per>=90&&per<=100)
    {
        cout<<"\n Your grade is A+";
    }
    else  if(per>=80&&per<=90)
    {
        cout<<"\n Your grade is A";
    }
     else if(per>=70&&per<=80)
    {
        cout<<"\n Your grade is B+";
    }
    else if(per>=60&&per<=70)
    {
        cout<<"\n Your grade is B";
    }
    else if(per>=50&&per<=60)
    {
        cout<<"\n Your grade is C";
    }
    else if(per>=40&&per<=50)
    {
        cout<<"\n Your grade is D";
    }
    else if(per<=40)
    {
        cout<<"\n Your grade is F";
    }
    return 0;
}