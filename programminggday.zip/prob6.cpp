#include<iostream>
using namespace std;
int main()
{
    string month;
    int days;
    float apartment_p,studio_p,disc_price;
    cout<<"Enter the month in which you stay(may,june,july,august,september,octoer):  ";
    cin>>month;
    cout<<"Enter the number of days you stay:  ";
    cin>>days;
  
    if (month=="may" || month=="october"){
        studio_p= 50.0;
       apartment_p= 65.0;     
               if(days>7){
                 disc_price*=0.95;
               }
               else if(days>14){
                disc_price*=0.70;
               }
              
            }
   else  if (month=="june" || month=="september"){
        studio_p= 75.2;
        apartment_p= 68.7; 
               if(days>14){
                 disc_price*=0.90;}
    }
   else  if(month=="july" || month=="august"){
       studio_p= 76.2;
        apartment_p= 77.0;
  if(days>14)
  {
    apartment_p*=0.9;
  }
    }
  
        float total_studio =studio_p*days;
        float total_ap=apartment_p*days;
         cout<<"\n Price ofstudio: "<<total_studio;
         cout<<"\n Pice apartment: "<<total_ap;
          
}