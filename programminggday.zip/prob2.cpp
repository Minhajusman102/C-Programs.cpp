#include<iostream>
using namespace std;
int main()
{
    string country;
    cout<<"Enter the country you live in: ";
    cin>>country;
    if (country!="germany" && country!="australlia")
    cout<<"You should come to vist these countries...";
    else
    cout<<"Good.. ";
return 0;
}