#include<iostream>
using namespace std;
int main()
{
    string day,fruit;
    float weight,ban_p,ap_p,ora_p,gra_p,kiwi_p=2.70,pineapple_p,grapes_p;
    cout<<"Enter the fruit: ";
    cin>>fruit;
    cout<<"Enter the day: ";
    cin>>day;
    cout<<"Enter the weigth: ";
    cin>>weight;
    if(day=="monday" || day=="tuesday" || day=="wednesday" || day=="thursday" || day=="friday"){
    ban_p =2.50;
     ap_p=1.20;
     ora_p=0.85;
     gra_p=1.45;
    kiwi_p=2.70;
    pineapple_p=5.50;
    grapes_p=3.85; 
     if(fruit=="apple"){
     ap_p=ap_p*weight;
    cout<<"price: "<<ap_p;}
     else if(fruit=="orange"){ 
     ora_p=ora_p*weight;
    cout<<"price: "<<ora_p;}
     else if(fruit=="grapes"){
     gra_p=gra_p*weight;
    cout<<"price: "<<gra_p;}
     else if(fruit=="kiwi"){
     kiwi_p=kiwi_p*weight;
    cout<<"price: "<<kiwi_p;}
     else if(fruit=="pineapple")
      {pineapple_p=pineapple_p*weight;
    cout<<"price: "<<pineapple_p;
      }
      else if(fruit=="grapefruit"){
       grapes_p=grapes_p*weight;
      cout<<"price: "<<grapes_p;}
    }
    cout<<"\n ";
     if(day=="saturday" || day=="sunday"){
    ban_p =2.70;
     ap_p=1.25;
     ora_p=0.90;
     gra_p=1.60;
    kiwi_p=3.00;
    pineapple_p=5.60;
    grapes_p=4.20; 
     if(fruit=="apple"){
     ap_p=ap_p*weight;
    cout<<"price: "<<ap_p;}
     else if(fruit=="orange"){ 
     ora_p=ora_p*weight;
    cout<<"price: "<<ora_p;}
     else if(fruit=="grapes"){
     gra_p=gra_p*weight;
    cout<<"price: "<<gra_p;}
     else if(fruit=="kiwi"){
     kiwi_p=kiwi_p*weight;
    cout<<"price: "<<kiwi_p;}
     else if(fruit=="pineapple")
      {pineapple_p=pineapple_p*weight;
    cout<<"price: "<<pineapple_p;
      }
      else if(fruit=="grapefruit"){
       grapes_p=grapes_p*weight;
      cout<<"price: "<<grapes_p;}
    }


}