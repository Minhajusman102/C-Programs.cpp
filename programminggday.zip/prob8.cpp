#include <iostream>
using namespace std;

int main() {
    int h, x, y;
    cout << "Enter value of h: ";
    cin >> h;
    cout << "Enter x coordinate: ";
    cin >> x;
    cout << "Enter y coordinate: ";
    cin >> y;

    bool insideBottom = (x > 0 && x < 3 * h && y > 0 && y < h);
    bool insideTop = (x > h && x < 2 * h && y > h && y < 4 * h);

    bool borderBottom = (x >= 0 && x <= 3 * h && (y == 0 || y == h)) ||
                        (y >= 0 && y <= h && (x == 0 || x == 3 * h));
    bool borderTop = (x >= h && x <= 2 * h && (y == h || y == 4 * h)) ||
                     (y >= h && y <= 4 * h && (x == h || x == 2 * h));

    if (insideBottom || insideTop)
        cout << "Inside";
    else if (borderBottom || borderTop)
        cout << "Border";
    else
        cout << "Outside";

    cout << endl;
    return 0;
}