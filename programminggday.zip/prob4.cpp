#include<iostream>
using namespace std;
int main()
{
int date;
string month;
cout<<"Enter the date of birth: ";
cin>>date;
cout<<"Enter the month: ";
cin>>month;
if ((date>=21 && month=="march") || (month == "april" && date <= 19))
 cout<< "Your Zodiac Sign is Aries " << endl;
else if ((date>=20 && month=="april" )|| (month == "may" && date <= 19))
 cout << "Your Zodiac Sign is taurus " << endl;
else if ((date>=20 && month=="may") || (month == "june" && date <= 20))
 cout << "Your Zodiac Sign is gemini " << endl;
else if ((date>=21 && month=="june") || (month == "july" && date <= 22))
 cout << "Your Zodiac Sign is cancer " << endl;
else if ((date>=23 && month=="july") || (month == "august" && date <= 22))
 cout << "Your Zodiac Sign is leo " << endl;
else if ((date>=23 && month=="august") || (month == "september" && date <= 22))
 cout << "Your Zodiac Sign is vigro" << endl;
else if ((date>=23 && month=="september") || (month == "october" && date <= 22))
 cout << "Your Zodiac Sign is libra " << endl;
else if ((date>=23 && month=="october") || (month == "november" && date <= 22))
 cout << "Your Zodiac Sign is scorpio" << endl;
else if ((date>=23 && month=="november") || (month == "december" && date <= 22))
 cout<< "Your Zodiac Sign is saggitarius" << endl;
else if ((date>=23 && month=="december") || (month == "january" && date <= 22))
 cout << "Your Zodiac Sign is capricon " << endl;
else if ((date>=23 && month=="january") || (month == "february" && date <= 22))
 cout << "Your Zodiac Sign is Acquarian" << endl;
else if ((date>=23 && month=="february") || (month == "march" && date <= 22))
 cout << "Your Zodiac Sign is pisces " << endl;
return 0;
}