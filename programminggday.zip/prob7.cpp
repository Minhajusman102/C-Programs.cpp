#include<iostream>
using namespace std;
int main()
{
         int sta_hr,sta_min,arrival_hr,arrival_min;
         cout<<"Exam starting time hour (0-23): ";
         cin>>sta_hr;
         cout<<"Exam starting time min(0-59): ";
         cin>>sta_hr;
         cout<<"Exam ending time hour(0-23): ";
         cin>>sta_hr;
         cout<<"Exam ending time min(0-59): ";
         cin>>sta_hr;
        int examtime=sta_hr*60+sta_min;
        int arrive_time=arrival_hr*60+arrival_min;
        int diff= arrive_time-examtime;
        if(diff==0){
            cout<<"On Time .. ";
        }
        else if(diff<0){
            int early= -diff;
                if(diff<=30){
                  cout<<"On Time .. ";
                  cout<<"Minutues before start: "<<early;
            }else{
                cout<<"early.. ";
                   if(diff<60){
                  cout<<"Minutues before start: "<<early;
                 }else{
                      int h=early/60;
                      int m=early%60;
                      cout<<h<<" : ";
                      if(m<10){
                        cout<<"0: ";
                        cout<<m<<"\n hours before start..";
                      }
                      }
                    }
                    else{
                        cout<<"LAte :"<<emdl;
                        if(diff<60)
                        cout<<diff<<" minutes before start "
                        else{
                             int h=early/60;
                      int m=early%60;
                      cout<<h<<" : ";
                        }
                         if(m<10){
                        cout<<"0: ";
                        cout<<m<<"\n hours before start..";
                      }
                    }
return 0;

}