#include<iostream>
using namespace std;
void timesten();
int main(){
   
    timesten();
return 0;
}
void timesten( ){
    int num=2;
int result=num*10;
cout<<"Result: "<<result;
}