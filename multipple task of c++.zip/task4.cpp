#include<iostream>
using namespace std;
int addnum(int,int);
int main(){
int x,y,w;
cout<<"Enter val of x and y: ";
cin>>x>>y;
w=addnum(x,y);
cout<<"sum: "<<w;
}
int addnum(int a,int b){
    return a+b;
}