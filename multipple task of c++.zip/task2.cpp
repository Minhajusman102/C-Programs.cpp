#include<iostream>
using namespace std;
double getradius();
double circlearea(double);
int main(){
    int a,c;
a=getradius();
c=circlearea(a);
cout<<"RADIUS: "<<a<<"\n AREA: "<<c;
return 0;

}
double getradius(){
    double r;
    cout<<"Enter radius: ";
    cin>>r;
    return r; 
}
double circlearea(double radius)
{
double area=3.149*radius*radius;
return area;
}