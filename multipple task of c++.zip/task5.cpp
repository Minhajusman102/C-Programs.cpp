#include<iostream>
using namespace std;
int large(int,int,int);
int main(){
int a,s,d,f;
cout<<"Enter val of a,s and d: ";
cin>>a>>s>>d;
f=large(a,s,d);
if(f==a)
cout<<"\nlargest : "<<a;
if(f==s)
cout<<"\nlargest : "<<s;
else
cout<<"\n largest: "<<d;
return 0;
}
int large(int x,int w,int z){
if(x>w && x>z)
return x;
if(w>x && w>z)
return w;
else 
return z;
}