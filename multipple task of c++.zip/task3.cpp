#include<iostream>
using namespace std;
bool iseven(int num);
int main(){
int a,c;
cout<<"enter val: ";
cin>>a;
c=iseven(a);
if(c==1)
cout<<"\n num is even";

return 0;
}
bool iseven(int num){
    if(num%2==0)
    return true;
else 
return false;
}