#include <iostream>
using namespace std;
int main()
{
    int n;
    long long dots;
    cout <<"Enter the triangle number = ";
    cin >>n;
    dots = n *(n + 1)/2;
    cout <<"Triangle("<<n<<") = "<<dots<< endl;
    return 0;
}
