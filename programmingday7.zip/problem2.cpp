#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
    int n, num;
    double countDivBy2 = 0, countDivBy3 = 0, countDivBy4 = 0, p1, p2, p3;
    cout<<"Enter Number of Counts= ";
    cin >> n;    
    for (int i = 0; i < n; ++i) {
        cout<<"Enter Number=";
        cin >> num;
        if (num % 2 == 0) {
            countDivBy2++;
        }
        if (num % 3 == 0) {
            countDivBy3++;
        }
        if (num % 4 == 0) {
            countDivBy4++;
        }
    }
    p1 = (countDivBy2/ n) * 100.0;
    p2 = (countDivBy3/n) * 100.0;
    p3 = (countDivBy4 /n) * 100.0;
    cout << fixed<<setprecision(2);
    cout << p1<<"%" << endl;
    cout <<p2 << "%" <<endl;
    cout <<p3<<"%";
    return 0;
}
