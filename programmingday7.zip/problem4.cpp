#include <iostream>
using namespace std;
int main()
{
    int period, doctors=7, treatedPatients=0, untreatedPatients=0, dailyPatients;
    cout<<"Enter Number of Periods= ";
    cin >> period;
    for (int day = 1; day<=period; ++day)
    {
        if (day%3 ==0)
        {
            if (untreatedPatients > treatedPatients)
                doctors++;        
        }        
        cout<<"Enter number of Daily Patients=";
        cin >> dailyPatients;
        if (dailyPatients <= doctors)
            treatedPatients += dailyPatients;
        else
            untreatedPatients += (dailyPatients - doctors);
    }
    cout <<"Treated patients: "<<treatedPatients<<"."<<endl;
    cout <<"Untreated patients: "<<untreatedPatients<<".";
    return 0;
}
