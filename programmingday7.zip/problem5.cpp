#include <iostream>
#include <iomanip> 
using namespace std;
int main() {
    int n, i, tons;
    double totalTons = 0, totalCost = 0, tonsByMinibus = 0, tonsByTruck = 0, tonsByTrain = 0, avgPrice, percentMinibus, percentTruck, percentTrain;

    cin >> n; 
    for (i = 0; i < n; ++i) {
        cin >> tons; 
        totalTons += tons;
        if (tons <= 3) {
            tonsByMinibus += tons;
            totalCost += (tons * 200.0);
        } else if (tons <= 11) {
            tonsByTruck += tons;
            totalCost += (tons * 175.0);
        } else {
            tonsByTrain += tons;
            totalCost += (tons * 120.0);
        }
    }
    avgPrice = totalCost / totalTons;
    percentMinibus = (tonsByMinibus / totalTons) * 100.0;
    percentTruck = (tonsByTruck / totalTons) * 100.0;
    percentTrain = (tonsByTrain / totalTons) * 100.0;
    cout << fixed <<setprecision(2);
    cout <<avgPrice << endl; 
    cout <<percentMinibus<< "%" << endl; 
    cout <<percentTruck << "%" << endl; 
    cout <<percentTrain<<"%"; 
    return 0;
}
