#include <iostream>
#include <cmath>
using namespace std;

string ones[] = {"","one","two","three","four","five","six","seven","eight","nine"};
string tens[] = {"","ten","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninety"};

void print2Digit(int n){
    if(n < 10) cout << ones[n];
    else cout << tens[n/10] << " " << ones[n%10];
}

int main() {
    double num;
    cin >> num;

    int rupees = (int)num;
    int paisa = round((num - rupees) * 100);

    cout << "Rupees: ";
    print2Digit(rupees/100000);
    cout << " lacs ";

    print2Digit((rupees/1000)%100);
    cout << " thousand ";

    print2Digit(rupees%100);
    cout << " rupees ";

    cout << "and ";
    print2Digit(paisa);
    cout << " paisa";

    return 0;
}
