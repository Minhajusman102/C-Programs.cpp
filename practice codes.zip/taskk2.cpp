#include<iostream>
#include<fstream>
using namespace std;
int main(){
ofstream file;
file.open("image.pgm",ios::app);
if(!file.is_open()){
    cout<<"!! Unable to open file !! ";
    return 0;
}
file<<"P2\n";
file<<"256  256 \n";
file<<"3\n ";
for (int i=0;i<256;i++){
    for (int j=0;j<256;j++){
        if (i<64)
        file<<"2 ";
        else if(i<128)
        file<<"0 ";
    else if(i<192)
    file<<"3 ";
        else if (i<256)
        file<<"1 ";

    }
}
file.close();
}