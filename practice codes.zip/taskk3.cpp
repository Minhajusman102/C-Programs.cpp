#include<iostream>
#include<fstream>
using namespace std;
int main(){
ofstream file("image11.pgm");
if(!file.is_open()){
    cout<<"!! Unable to open file !! ";
    return 0;
}
file<<"P2\n";
file<<"256 256\n";
file<<"15\n ";
for (int i=0;i<256;i++){
    
    int val=i/16;
   { for (int j=0;j<256;j++){
       file<<val<<" ";
       }

    }
    file<<"\n";
}
file.close();
return 0;
}