#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream file("pattern2.pgm");

  
    file << "P2" << endl;
    file << "256 256" << endl;
    file << "255" << endl;

    int width = 256;
    int height = 256;
    int blocks = 16;
    int blockSize = width / blocks;   

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {

            int rowBlock = i / blockSize;
            int colBlock = j / blockSize;
            if ((rowBlock + colBlock) % 2 == 0)
                file << "0 ";
            else
                file << "255 ";
        }
        file << endl;
    }

    file.close();
}