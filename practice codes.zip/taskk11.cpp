#include <iostream>
#include <fstream>
using namespace std;
int main() {
    ifstream input("input.ppm");
    ofstream output("negative.ppm");
    string magic;
    int width, height, maxVal;
    input >> magic;
    input >> width >> height;
    input >> maxVal;
    output << magic << endl;
    output << width << " " << height << endl;
    output << maxVal << endl;
    int value;
    while (input >> value) {
        output << (maxVal - value) << " ";
    }

    input.close();
    output.close();

    cout << "Negative PPM file created successfully!" << endl;
    return 0;
}
