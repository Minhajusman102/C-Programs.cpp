#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    srand(time(0));

    int trade[12][12][5][3][5][12];
    for(int o=0;o<12;o++)
        for(int d=0;d<12;d++)
            for(int p=0;p<5;p++)
                for(int t=0;t<3;t++)
                    for(int tr=0;tr<5;tr++)
                        for(int m=0;m<12;m++)
                            trade[o][d][p][t][tr][m] = 30000 + rand()%90001;

    for(int o=0;o<12;o++){
        cout << "Origin Country " << o+1 << ": ";
        for(int tr=0;tr<5;tr++){
            int count = 0;
            for(int d=0;d<12;d++)
                for(int p=0;p<5;p++)
                    for(int t=0;t<3;t++)
                        for(int m=0;m<12;m++)
                            if(trade[o][d][p][t][tr][m] > 0)
                                count++;

            cout << "Slab " << tr*20 << "-" << (tr+1)*20 << "% = " << count << "  ";
        }
        cout << endl;
    }
    return 0;
}
