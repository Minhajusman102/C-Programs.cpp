#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main() {
    srand(time(0));

    long trade[12][12][5][3][1][12];
    for (int o = 0; o < 12; o++)
        for (int d = 0; d < 12; d++)
            for (int p = 0; p < 5; p++)
                for (int t = 0; t < 3; t++)
                    for (int m = 0; m < 12; m++)
                        trade[o][d][p][t][0][m] = 30000 + rand() % 90001;

    long totalTrade[12][12] = {0};
    for (int o = 0; o < 12; o++) {
        for (int d = 0; d < 12; d++) {
            if (o != d) {
                for (int p = 0; p < 5; p++)
                    for (int t = 0; t < 3; t++)
                        for (int m = 0; m < 12; m++)
                            totalTrade[o][d] += trade[o][d][p][t][0][m];
            }
        }
    }
    cout << "\nCountry-to-Country Trade Matrix\n\n";
    for (int o = 0; o < 12; o++) {
        for (int d = 0; d < 12; d++) {
            if (o == d)
                cout << "   —   ";
            else
                cout << totalTrade[o][d] << " ";
        }
        cout << endl;
    }
    return 0;
}
