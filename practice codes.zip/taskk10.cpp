#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream input("input.pgm");     // Original PGM file
    ofstream output("negative.pgm"); // New inverted file

    string magic;
    int width, height, maxVal;

    // Read header
    input >> magic;
    input >> width >> height;
    input >> maxVal;

    // Write same header to output
    output << magic << endl;
    output << width << " " << height << endl;
    output << maxVal << endl;

    int pixel;
    while (input >> pixel) {
        output << (maxVal - pixel) << " ";
    }

    input.close();
    output.close();

    cout << "Negative PGM file created successfully!" << endl;
    return 0;
}
