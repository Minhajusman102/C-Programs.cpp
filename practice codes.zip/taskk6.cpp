#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream file("strips4.pgm");

    // Header of PGM file
    file << "P2" << endl;          // Magic number
    file << "256 256" << endl;     // Width and Height
    file << "15" << endl;          // Maximum gray value

    int width = 256;
    int height = 256;
    int strips = 16;
    int stripWidth = width / strips;

    // Two nested loops for pixels
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {

            // Decide strip number
            int stripNo = j / stripWidth;

            // Gray value for that strip
            int grayValue = stripNo;

            file << grayValue << " ";
        }
        file << endl;
    }

    file.close();
    cout << "PGM file strips4.pgm created successfully!" << endl;

    return 0;
}
