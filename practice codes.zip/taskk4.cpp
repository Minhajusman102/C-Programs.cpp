#include<iostream>
#include<fstream>
using namespace std;
int main(){
ofstream file;
file.open("image12.pgm",ios::app);
if(!file.is_open()){
    cout<<"!! Unable to open file !! ";
    return 0;
}
file<<"P2\n";
file<<"256 256\n";
file<<"255\n ";
for (int i=0;i<256;i++){
    for(int j=0;j<256;j++){
    for (int k=0;k<255;k++)
    file<<k<<" ";
}
}
file.close();
}