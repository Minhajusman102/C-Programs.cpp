#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream file("pattern4.ppm");
    file << "P3" << endl;
    file << "256 256" << endl;
    file << "255" << endl;

    int width = 256;
    int height = 256;
    int blocks = 16;
    int blockSize = width / blocks;   
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {

            int rowBlock = i / blockSize;
            int colBlock = j / blockSize;

            int value;
            if ((rowBlock + colBlock) % 2 == 0)
                value = 40;    
            else
                value = 220;    
            file << value << " " << value << " " << value << " ";
        }
        file << endl;
    }

    file.close();
    cout << "PPM file pattern4.ppm created successfully!" << endl;

    return 0;
}
