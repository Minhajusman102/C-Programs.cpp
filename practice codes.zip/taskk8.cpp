#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream file("pattern3.pgm");

    // Step 1: Write PGM header
    file << "P2" << endl;
    file << "256 256" << endl;
    file << "255" << endl;

    int width = 256;
    int height = 256;
    int squareSize = 32;   // Each square is 32x32 pixels

    // Step 2: Generate chessboard using nested loops
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {

            // Determine which square the pixel belongs to
            int rowSquare = i / squareSize;
            int colSquare = j / squareSize;

            // Chessboard logic
            if ((rowSquare + colSquare) % 2 == 0)
                file << "10 ";     // Near 0 (black)
            else
                file << "245 ";    // Near 255 (white)
        }
        file << endl;
    }

    file.close();
    cout << "PGM chessboard file pattern3.pgm created successfully!" << endl;

    return 0;
}
