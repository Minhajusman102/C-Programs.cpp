#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

int main() {
    ifstream file("countries of the world.csv");
    string line;

    getline(file, line); /

    while(getline(file, line)) {
        stringstream ss(line);
        string col[6];

        for(int i=0;i<6;i++)
            getline(ss, col[i], ',');

        cout << col[0] << " | " << col[1] << " | "
             << col[2] << " | " << col[3] << " | "
             << col[4] << " | " << col[5] << endl;
    }
    file.close();
    return 0;
}
