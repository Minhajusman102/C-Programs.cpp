#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <conio.h> 
#include <windows.h>

using namespace std;

const int GRID_SIZE = 20;
const int GOLD_PER_LEVEL = 4; // Player needs 4 gold to level up
const int NUM_ZOMBIES = 2; // Number of zombie enemies

struct Position {
    int x;
    int y;
};

// Global Variables
Position player = {10, 10};
Position zombies[NUM_ZOMBIES]; // Array of zombie positions
int goldMap[GRID_SIZE][GRID_SIZE];
int goldCollected = 0;
int goldThisLevel = 0; // Track gold collected in current level
int lives = 3; 
int currentLevel = 1;

void clearScreen() {
    system("cls"); 
}

void initZombies() {
    // Initialize zombies at different corners
    zombies[0] = {0, 0}; // Top-left corner
    zombies[1] = {GRID_SIZE - 1, GRID_SIZE - 1}; // Bottom-right corner
}

void initGold() {
    for (int y = 0; y < GRID_SIZE; y++) {
        for (int x = 0; x < GRID_SIZE; x++) {
            if (x == player.x && y == player.y) {
                goldMap[y][x] = 0;
            } else {
                // More gold spawns in higher levels
                int spawnChance = 15 - (currentLevel - 1); // Gets easier to find gold
                if (spawnChance < 8) spawnChance = 8; // Minimum difficulty
                goldMap[y][x] = (rand() % spawnChance == 0) ? 1 : 0;
            }
        }
    }
}

void drawGrid() {
    clearScreen();
    cout << "=========================================" << endl;
    cout << "       ZOMBIE SURVIVAL - LEVEL " << currentLevel << endl;
    cout << "=========================================" << endl;
    cout << "Total Score: " << goldCollected << " | Lives: " << lives << endl;
    cout << "Gold this level: " << goldThisLevel << "/" << GOLD_PER_LEVEL << endl;
    cout << "Zombies: " << NUM_ZOMBIES << " enemies hunting you!" << endl;
    cout << "-----------------------------------------" << endl;
    
    for (int y = 0; y < GRID_SIZE; y++) {
        for (int x = 0; x < GRID_SIZE; x++) {
            bool isZombie = false;
            
            // Check if any zombie is at this position
            for (int i = 0; i < NUM_ZOMBIES; i++) {
                if (x == zombies[i].x && y == zombies[i].y) {
                    cout << "Z "; 
                    isZombie = true;
                    break;
                }
            }
            
            if (!isZombie) {
                if (x == player.x && y == player.y) cout << "P "; 
                else if (goldMap[y][x] == 1) cout << "$ "; 
                else cout << ". "; 
            }
        }
        cout << endl;
    }
    cout << "-----------------------------------------" << endl;
    cout << "Use WASD to move | X to Exit" << endl;
}

void moveZombies() {
    // Zombie moves faster at higher levels (moves multiple times)
    int zombieSpeed = 1 + (currentLevel - 1) / 2; // Speed increases every 2 levels
    if (zombieSpeed > 3) zombieSpeed = 3; // Cap at 3 moves per turn
    
    // Move each zombie
    for (int z = 0; z < NUM_ZOMBIES; z++) {
        for (int i = 0; i < zombieSpeed; i++) {
            if (zombies[z].x < player.x) zombies[z].x++;
            else if (zombies[z].x > player.x) zombies[z].x--;

            if (zombies[z].y < player.y) zombies[z].y++;
            else if (zombies[z].y > player.y) zombies[z].y--;
        }
    }
}

bool checkZombieCollision() {
    // Check if player collided with any zombie
    for (int i = 0; i < NUM_ZOMBIES; i++) {
        if (player.x == zombies[i].x && player.y == zombies[i].y) {
            return true;
        }
    }
    return false;
}

void levelUp() {
    currentLevel++;
    goldThisLevel = 0; // Reset gold counter for new level
    
    clearScreen();
    cout << "\n\n" << endl;
    cout << "**************************************" << endl;
    cout << "*                                    *" << endl;
    cout << "*         LEVEL UP!!!                *" << endl;
    cout << "*      Now entering LEVEL " << currentLevel << "         *" << endl;
    cout << "*                                    *" << endl;
    cout << "**************************************" << endl;
    cout << "\nZombies are getting faster!" << endl;
    cout << "Get ready..." << endl;
    Sleep(2500);
    
    // Reset positions for new level
    player = {10, 10};
    initZombies();
    
    // Regenerate gold for new level
    initGold();
}

int main() {
    srand(time(0));
    initZombies();
    initGold();

    bool running = true;
    while (running && lives > 0) {
        drawGrid();

        char input = _getch(); 
        if (input == 'x' || input == 'X') break;

        // Player movement
        if ((input == 'w' || input == 'W') && player.y > 0) player.y--;
        if ((input == 's' || input == 'S') && player.y < GRID_SIZE - 1) player.y++;
        if ((input == 'a' || input == 'A') && player.x > 0) player.x--;
        if ((input == 'd' || input == 'D') && player.x < GRID_SIZE - 1) player.x++;

        // Check for gold collection
        if (goldMap[player.y][player.x] == 1) {
            goldCollected += 10;
            goldThisLevel++;
            goldMap[player.y][player.x] = 0;
            
            // Check if player collected 4 gold coins (level up condition)
            if (goldThisLevel >= GOLD_PER_LEVEL) {
                levelUp();
                continue; // Skip zombie movement and collision check for this turn
            }
        }

        moveZombies();

        // Check for Collision with any Zombie
        if (checkZombieCollision()) {
            lives--; 
            
            drawGrid();
            cout << "\n!!! YOU GOT CAUGHT BY A ZOMBIE !!!" << endl;
            cout << "Lives remaining: " << lives << endl;
            
            // Reset positions
            player = {10, 10};
            initZombies();
            
            if (lives > 0) {
                cout << "Restarting in 2 seconds..." << endl;
                Sleep(2000);
            }
        }
    }

    // Game Over Screen
    clearScreen();
    if (lives <= 0) {
        cout << "\n\n" << endl;
        cout << "=========================================" << endl;
        cout << "            GAME OVER                    " << endl;
        cout << "=========================================" << endl;
        cout << " You ran out of lives!                  " << endl;
        cout << " Final Score: " << goldCollected << "                   " << endl;
        cout << " Final Level: " << currentLevel << "                    " << endl;
        cout << "=========================================" << endl;
    } else {
        cout << "\n\nGame exited." << endl;
        cout << "Final Score: " << goldCollected << endl;
        cout << "Level Reached: " << currentLevel << endl;
    }

    return 0;
}