#include<iostream>
#include<iomanip>
using namespace std;
int main()
{

int farenheit,celcius;
cout<<"\n Enter temep in celcius: ";
cin>>farenheit;
cout<<endl;
celcius=5/9*(farenheit-32);
cout<<"farenheit: "<<farenheit<<"\n celcius: "<<celcius;
return 0;
}