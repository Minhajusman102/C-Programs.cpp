 #include<iostream>
using namespace std;
int main()
{
    float hours=35.45,rate=14.00,tolrance=0.01000,pay;
    cout<<"hours: "<<hours<<"\n rate: "<<rate<<"\n tolerance: "<<tolrance<<"\n pay: "<<hours*rate;
    cout<<scientific;
    cout<<"\n Scientific notation ";
    cout<<"hours: "<<hours<<"\n rate: "<<rate<<"\n tolerance: "<<tolrance<<"\n pay: "<<hours*rate;
    cout<<"\n tolerance: "<<tolerance<<endl;
   return 0;
    
}