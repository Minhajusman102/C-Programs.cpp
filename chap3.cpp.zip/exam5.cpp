
#include<iostream>
using namespace std;
int main()
{
    char ch;
    cout<<" \n enter a character : ";
    cin.get(ch);
    cout<<"\n After first cin.get(ch): "<<ch<<endl;
     cin.get(ch);
    cout<<"\n After second cin.get(ch): "<<ch<<endl;
    cin.putback(ch);
     cin.get(ch);
    cout<<"\n After third cin.get(ch) and put back: "<<ch<<endl;
    ch=cin.peek();
    cout<<"\n after peek: "<<ch;
    cin.get(ch);
    cout<<"\n After t cin.get(ch): "<<ch<<endl;
}