// chp3 example 1
#include<iostream>
using namespace std;
int main()
{
int a=25,num;
char ch1,ch2;
cout<<"val of ch1: ";
cin.get(ch1);
cout<<"val of ch2: ";
cin.get(ch2);
cout<<"\n val of num: ";
cin>>num;
cout<<"\n ch1: "<<ch1;
cout<<"\n ch2: "<<ch2;
cout<<"\n num: "<<num;
return 0;
}