#include<iostream>
using namespace std;
int main()
{
    int a,b;
    cout<<"\n enter the val of a and b: ";
    cin>>a;
    cin.ignore(100,'\n');
    cin>>b;
    cout<<"\n a: "<<a<<b;
    return 0;
}