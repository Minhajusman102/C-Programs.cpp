#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    const double pi=3.14;
    float radius,volume,point1x,point2x,point1y,point2y,distance;
    string str;
    cout<<"Enter radius of sphere: ";
    cin>>radius;
    cout<<endl;
    volume=(4.0/30.0)*pi*pow(radius,3);
    cout<<"\n Enter the cordinates of X-Y plane: ";
    cin>>point1x>>point2x>>point1y>>point2y;
    distance=sqrt(pow(point2x - point1x, 2)+(pow(point2y-point1y,2)));
    str="programming with c++ ";
    cout<<"\n Distance= "<<distance;
    cout<<"\n number of characters in string : "<<str.length()<<endl;
     return 0;
}