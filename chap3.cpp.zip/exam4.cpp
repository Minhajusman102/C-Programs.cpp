#include<iostream>
using namespace std;
int main()
{
    char ch1,ch2;
cout<<" Enter val of X AND Y: ";
cin>>ch1;
cin.ignore(5,'.');
cin>>ch2;
cout<<"\n ch1: "<<ch1<<" \n ch2: "<<ch2;
return 0;
}