#include<iostream>
using namespace std;
int main()
{
    string name;
    int age,weight;
    float height;
    cout<<" Enter your name: ";
    cin>>name;
    cout<<" Enter your age: ";
    cin>>age;
    cout<<" Enter your height: ";
    cin>>height;
     cout<<" Enter your weight: ";
    cin>>weight;
    cout<<"\n your name is : "<<name<<"\n age is : "<<age<<"\n weight: "<<weight<<"\n height: "<<height;
    cin.clear();    // restore all input
    cin.ignore(200,'\n');
    cout<<" Enter your name: ";
    cin>>name;
    cout<<" Enter your age: ";
    cin>>age;
    cout<<" Enter your height: ";
    cin>>height;
     cout<<" Enter your weight: ";
    cin>>weight;
    cout<<"\n your name is : "<<name<<"\n age is : "<<age<<"\n weight: "<<weight<<"\n height: "<<height;
    return 0;
     
}