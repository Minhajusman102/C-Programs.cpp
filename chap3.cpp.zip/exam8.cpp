#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
    const float pi=3.14;
    float height=12.67,radius=12.00,volume;
    cout<<fixed<<showpoint;
    cout<<setprecision(2)<<" : SET PRECISION 2"<<endl;
    cout<<"\n Radius: "<<radius;
    cout<<"\n heigth: "<<height;
    cout<<"\n volume: "<<radius*pi*radius*height;
      cout<<"\n pi: "<<pi;
    cout<<setprecision(3)<<" : SET PRECISION 2"<<endl;
    cout<<"\n Radius: "<<radius;
    cout<<"\n heigth: "<<height;
    cout<<"\n volume: "<<radius*pi*radius*height;
      cout<<"\n pi: "<<pi;
      cout<<setprecision(3)<<" : SET PRECISION 2"<<endl;
    cout<<"\n Radius: "<<radius;
    cout<<"\n heigth: "<<height;
    cout<<"\n volume: "<<radius*pi*radius*height;
      cout<<"\n pi: "<<pi;  
      cout<<"\n line 24: ";
      cout<<setprecision(3)<<radius<<", ";
      cout<<setprecision(2)<<height<<" , ";
      cout <<setprecision(5)<<"pi:"<<pi<<endl;
     
      return 0;
}