#include<iostream>
#include<iomanip>
using namespace std;
int main()
{

int farenheit,celcius;
cout<<"\n Enter temep in celcius: ";
cin>>farenheit;
cout<<endl;
celcius=static_cast<int>(5.0/9*(farenheit-32));
cout<<"farenheit: "<<farenheit<<"\n celcius: "<<celcius;
return 0;
}