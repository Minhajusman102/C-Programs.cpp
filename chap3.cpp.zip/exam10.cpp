#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
string name="Jessica";
    double gpa=3.75;
    int scholarship=7850;
    cout<<"1234456789012345678901234567890"<<endl;
    cout<<fixed<<showpoint<<setp    recision(2);
    cout<<left;
    cout<<setw(10)<<name<<setw(7)<<gpa<<setw(8)<<scholarship<<endl;
    cout<<setfill('*');
     cout<<setw(10)<<name<<setw(7)<<gpa<<setw(8)<<scholarship<<endl;
     cout<<setw(10)<<setfill('@')<<name<<setw(7)<<setfill('#')<<gpa<<setw(8)<<setfill('^')<<scholarship;
     cout<<setfill(' ');
     cout<<setw(10)<<name<<setw(7)<<gpa<<setw(8)<<scholarship<<endl;
     cout<<right;
    cout<<setw(10)<<name<<setw(7)<<gpa<<setw(8)<<scholarship<<endl;
    cout<<setfill('*');
     cout<<setw(10)<<name<<setw(7)<<gpa<<setw(8)<<scholarship<<endl;
     cout<<setw(10)<<setfill('@')<<name<<setw(7)<<setfill('#')<<gpa<<setw(8)<<setfill('^')<<scholarship;
     cout<<setfill(' ');
     cout<<setw(10)<<name<<setw(7)<<gpa<<setw(8)<<scholarship<<endl;
     return 0;
}