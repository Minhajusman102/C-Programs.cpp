#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
string name;
double adultticketprice,childticketprice,percentdonation,amountdonated,saleamount,grossamount;
int noofadultticket,noofchildticket;
cout<<fixed<<showpoint<<setprecision(2);
cout<<"\n Enter the movie name: "<<name;
getline(cin,name);
cout<<endl;
cout<<"\n Enter the price of adult ticket: ";
cin>>adultticketprice;
cout<<"\n Enter the price of child ticketr: ";
cin>>childticketprice;
cout<<"\n Enter the no of soldchild ticket:   ";
cin>>noofchildticket;
cout<<"\n Enter the no of sold adult ticket: ";
cin>>noofadultticket;
cout<<"\n Enter the percenatge donation: ";
cin>>percentdonation;
grossamount=adultticketprice*noofadultticket+childticketprice*noofchildticket;
amountdonated=grossamount*percentdonation/100;
saleamount=grossamount-amountdonated;
cout<<"_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*"
<<"_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*"<<endl;
cout<<setfill('.')<<left<<setw(35)<<"Movie name: "<<right<<" "<<name<<endl;
cout<<left<<setw(35)<<" Number of tickets sold: "<<setfill(' ')<<right<<setw(10)<<noofadultticket+noofchildticket<<endl;
cout<<setfill('.')<<left<<setw(35)<<" Gross amount: "<<setfill<<(' ')<<right<<"$"<<setw(8)<<grossamount<<endl;
cout<<setfill('.')<<left<<setw(35)<<" Percentage of amount donmated: " <<setfill('')<<right<<setw(9)<<percentdonation<<"% "<<endl;
cout<<setfill('.')<<left<<setw(35)<<" Amount donated: "<<setfill<<(' ')<<right<<"$"<<setw(8)<<"$ "<<setw(8)<<amountdonated<<endl;
cout<<setfill('.')<<left<<setw(35)<<" net sale: "<<setfill<<(' ')<<right<<"$"<<setw(8)<<setw(8)<<saleamount<<endl;
return 0;

}