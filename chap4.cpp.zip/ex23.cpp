#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;
int main()
{
	ifstream inFile;
	ofstream outFile;
	double team1,team2,team3,team4,average;
	string fristname,lastname;
	inFile.open("test.txt");
	if (! inFile)
	{
		cout<<"\n Cannot open infile .The program terminates."<<endl;
		return 1;
	}
	outFile.open("testavg.txt");
	outFile<<fixed<<showpoint;
	outFile<<setprecision(2);
	cout<<"Processing data "<<endl;
	inFile>>fristname>>lastname;
     outFile<<"Stuent namr: "<<fristname<<" "<<lastname;
	inFile>>team1>>team2>>team3>>team4;
	outFile<<"Test scores: "<<setw(4)<<team1<<setw(4)<<team2<<setw(4)<<team3<<setw(4)<<team4;
	average=(team1+team2+team3+team4)/5.0;
	outFile<<"Average score: "<<average;
	return 0;
}
