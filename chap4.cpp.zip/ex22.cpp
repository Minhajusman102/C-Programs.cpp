#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"enter the num: ";
	cin>>num;
	if(0<=num && num<=10)
	cout<<"\n num is within 0 and 10..";
	else
	cout<<"\n num is not within 0 and 10..";
	return 0;
}

