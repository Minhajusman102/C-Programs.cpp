#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main()
{
	double x=1.0;
	double y=3.0/7.0+2.0/7.0+2.0/7.0;
	cout<<fixed<<showpoint<<setprecision(17);
	cout<<"3.0/7.0+2.0/7.0+2.0/7.0 = "<<3.0/7.0+2.0/7.0+2.0/7.0<<endl;
	cout<<" x="<<x<<endl;
	cout<<"y= "<<y<<endl;
	if(x==y)
	cout<<"x and y are the same. "<<endl;
	else
	cout<<"x and y are not the same."<<endl;
	if(fabs(x-y)<0.00001)
	{cout<<"x and y are same within tolerance."
	<<" 0.00001. "<<endl;
	
	}
	else
	cout<<"x and y are not same within tolerance 0.00001. "<<endl;
	return 0;
}
