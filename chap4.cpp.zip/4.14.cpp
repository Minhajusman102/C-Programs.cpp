#include<iostream>
#include<iomanip>
using namespace std;
int main() {
    double suitcaseDimension,suitcaseWeight,additionalCharges=0.0;
    cout<<"Line 10: Enter suitcase Dimensions"<<"(lenght+width+depth) in inches:";
    cin>>suitcaseDimension;
    cout<<endl;
    cout<<"Line 13: Enter suitcase weight in pounds:";
    cin>>suitcaseWeight;
    cout<<endl;
    if (suitcaseDimension>108 || suitcaseWeight>50) 
    additionalCharges=50.00;
    cout<<"Line 18: Additional suitcase charges:$"<<additionalCharges<<endl;
    return 0;
}
    