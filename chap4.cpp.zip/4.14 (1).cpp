#include <iostream>
#include<iomanip>
using namespace std;
int main() {
	string str1="hello",str2="hen",str3="air",str4="bill",str5="big";
	
	
	
	
	
	
}
