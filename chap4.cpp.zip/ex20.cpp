#include<iostream>

using namespace std;
int main()
{
	char gender;
	int age;
	float policyrate;
	cout<<"Enter the gender(m or f): ";
	cin>>gender;
	cout<<"Enter your age: ";
	cin>>age;
	if(gender=='m')
	    if(age<21)
	    policyrate=0.05;
	    else
	     policyrate=0.35;
	else if(gender=='f')
	    if(age<21)
	    policyrate=0.04;
	    else
	     policyrate=0.30;
	cout<<"\Gender: "<<gender<<"\n Age: "<<age<<"\n Policy rate; "<<policyrate;
	return 0;  
}
