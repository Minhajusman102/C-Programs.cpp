#include <iostream>
using namespace std;
int main() {
    double hours,rate,wages;
    cout<<"Line 8: Enter working hours and rate:";
    cin>>hours>>rate;
    if (hours>40.0)
        wages=40.0*rate+1.5*rate*(hours-40.0);
    else
        wages=hours*rate;
    cout<<endl;    
    cout<<"Total wages=$"<<wages<<endl;
    return 0;
}
    